#!/bin/bash

DIR=$(dirname $BASH_SOURCE)
echo $DIR
